﻿using UnityEngine;
using System.Collections;

namespace Chapter1
{
    public class PistolFire : MonoBehaviour
    {

        public GameObject pistolPrefab;
        private Transform myTransform;
        public float propulsionForce;

        // Use this for initialization
        void Start()
        {
            SetInitialReferences();
        }

        // Update is called once per frame
        void Update()
        {
            if (Input.GetButtonDown("Fire1"))
            {
                SpawnBullet();
            }
        }

        void SetInitialReferences()
        {
            myTransform = transform;
        }


        void SpawnBullet()
        {
            GameObject go = (GameObject)Instantiate(pistolPrefab, myTransform.TransformPoint(0, 0, 0.3f), myTransform.rotation);
            go.GetComponent<Rigidbody>().AddForce(myTransform.forward * propulsionForce, ForceMode.Impulse);
            Destroy(go, 10);
        }
    }
}

