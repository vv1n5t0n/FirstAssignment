﻿using UnityEngine;
using System.Collections;
//note make your triggers small in height and width
namespace Chapter1
{
    public class TriggerExample : MonoBehaviour
    {
       // private GameManager_EventMaster eventMasterScript;
        public GameObject wall;

        void Start()
        {
         //   SetInitialReferences();
        }

        void OnTriggerEnter(Collider other)
        {

           // eventMasterScript.CallMyGeneralEvent();
            Destroy(gameObject);
            Destroy(wall);
        }
        /*
        void SetInitialReferences()
        {

            eventMasterScript = GameObject.Find("GameManager").GetComponent<GameManager_EventMaster>();

        }
         */

    }
}