﻿using UnityEngine;
using System.Collections;

public class Black : MonoBehaviour
{

    void OnCollisionEnter(Collision col)
    {

        if (col.gameObject.name == "Bullet(Clone)" || col.gameObject.name == "Grenade(Clone)")
        {
            Destroy(gameObject);
        }
    }
    // Use this for initialization
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.black;
    }
}