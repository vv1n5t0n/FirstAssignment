﻿using UnityEngine;
using System.Collections;

public class Yellow : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {
        gameObject.GetComponent<Renderer>().material.color = Color.yellow;
    }
}
